import java.util.*;
import java.io.*;

/*****************************************************************************************
 * // class Router 
 * // Purpose: This class represents a router 
 * Linda Crane,   CST8130
 * // data members:
 * //  routingTable - ArrayList to hold up to MaxEntries routing table entries 
 * //  numEntries - number of entries currently in the table  
 * //  maxEntries - maximum number of entries  in table 
 * // methods: constructor 
 * // displayTable - displays results of "show ip route" command on device-ie entries in table 
 * // processPackets (Packet) - uses the parameter "packet" - processes it    
 ***************************************************************************************/
class Router {
	protected ArrayList<RoutingTableEntry> routingTable;

	public Router() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter number of entries maximum for array: ");
		int maxEntries = keyboard.nextInt();

		routingTable = new ArrayList<RoutingTableEntry>(maxEntries);
		// check this worked***********************************************

	}
	
	

	public void processPackets(Packet inPacket) {

		boolean found = false;
		String port = null;
		int upperLimit = routingTable.size()-1;
		int lowerLimit = 0;
		int mid;
		RoutingTableEntry temp;
		while (upperLimit >= lowerLimit && !found) {
		    mid = (upperLimit + lowerLimit) /2;
		
			temp = routingTable.get(mid);
			port = temp.searchForPort(inPacket.getDestNetwork());
			if (port != null) {
				found = true;
				break;
			}
			else if (temp.getDestination().isGreaterThan(inPacket.getDestNetwork()))
					upperLimit = mid-1;
			else    lowerLimit = mid+1;
		}
	
		boolean addToTable = false;
		if (found)
			addToTable = inPacket.processFoundPacket(port);
		else
			addToTable = inPacket.processNotFoundPacket(port);

		if (addToTable) {	
				RoutingTableEntry newOne = new RoutingTableEntry();
				newOne.addEntry(inPacket.getDestNetwork(),inPacket.getPacketData());
				int i = 0;
				for (i=0; i < routingTable.size(); i++) {
					if (routingTable.get(i).isGreaterThan(newOne))
						break;
				}
				routingTable.add(i, newOne);
				
		}
	}
	
	public void displayTable() {
		System.out.println("\nRouting table...\n");
		for (RoutingTableEntry rte:routingTable)
			System.out.println(rte);
	}
};
